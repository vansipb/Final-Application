﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SuperCarCenter;

namespace SuperCarCenter
{
    public static class ConsoleView
    {
        #region ENUMERABLES


        #endregion

        #region FIELDS

        //
        // window size
        //
        private const int WINDOW_WIDTH = ViewSettings.WINDOW_WIDTH;
        private const int WINDOW_HEIGHT = ViewSettings.WINDOW_HEIGHT;

        //
        // horizontal and vertical margins in console window for display
        //
        private const int DISPLAY_HORIZONTAL_MARGIN = ViewSettings.DISPLAY_HORIZONTAL_MARGIN;
        private const int DISPALY_VERITCAL_MARGIN = ViewSettings.DISPALY_VERITCAL_MARGIN;

        #endregion

        #region CONSTRUCTORS

        #endregion

        #region METHODS

        /// <summary>
        /// method to display the manager menu and get the user's choice
        /// </summary>
        /// <returns></returns>
        public static AppEnum.ManagerAction GetUserActionChoice()
        {
            AppEnum.ManagerAction userActionChoice = AppEnum.ManagerAction.None;
            //
            // set a string variable with a length equal to the horizontal margin and filled with spaces
            //
            string leftTab = ConsoleUtil.FillStringWithSpaces(DISPLAY_HORIZONTAL_MARGIN);

            //
            // set up display area
            //
            DisplayReset();

            //
            // display the menu
            //
            DisplayMessage("");
            Console.WriteLine(ConsoleUtil.Center("Super Car Center Menu", WINDOW_WIDTH));
            DisplayMessage("");

            Console.WriteLine(
                leftTab + "1. Display Car Inventory" + Environment.NewLine +
                leftTab + "2. Display Car Details" + Environment.NewLine +
                leftTab + "3. Query Cars by Price" + Environment.NewLine +
                leftTab + "4. Query Cars by HorsePower" + Environment.NewLine +
                leftTab + "5. Add a Car" + Environment.NewLine +
                leftTab + "6. Delete a Car" + Environment.NewLine +
                leftTab + "7. Edit a Car" + Environment.NewLine +
                leftTab + "E. Exit" + Environment.NewLine);

            DisplayMessage("");
            DisplayPromptMessage("Enter the number/letter for the menu choice: ");
            ConsoleKeyInfo userResponse = Console.ReadKey(true);

            switch (userResponse.KeyChar)
            {
                case '1':
                    userActionChoice = AppEnum.ManagerAction.ListCarInventory;
                    break;
                case '2':
                    userActionChoice = AppEnum.ManagerAction.DisplayCarInfo;
                    break;
                case '3':
                    userActionChoice = AppEnum.ManagerAction.QuerySuperCarsByPrice;
                    break;
                case '4':
                    userActionChoice = AppEnum.ManagerAction.QuerySuperCarsByHp;
                    break;
                case '5':
                    userActionChoice = AppEnum.ManagerAction.AddCarInfo;
                    break;
                case '6':
                    userActionChoice = AppEnum.ManagerAction.DeleteCarInfo;
                    break;
                case '7':
                    userActionChoice = AppEnum.ManagerAction.UpdateCarInfo;
                    break;
                case 'E':
                case 'e':
                    userActionChoice = AppEnum.ManagerAction.Quit;
                    break;
                default:
                    DisplayMessage("");
                    DisplayMessage("");
                    DisplayMessage("It appears you have selected an incorrect choice.");
                    DisplayMessage("");
                    DisplayMessage("Press any key to try again or the ESC key to exit.");

                    userResponse = Console.ReadKey(true);
                    if (userResponse.Key == ConsoleKey.Escape)
                    {
                        userActionChoice = AppEnum.ManagerAction.Quit;
                    }
                    break;
            }

            return userActionChoice;
        }

        // method to display all super cars info
        public static void DisplayAllSuperCars(List<CarInfo> superCar)
        {
            DisplayReset();
            Console.ForegroundColor = ConsoleColor.Red;
            DisplayMessage("");
            Console.WriteLine(ConsoleUtil.Center("List of Super Cars", WINDOW_WIDTH));
            DisplayMessage("");
            Console.ResetColor();
            DisplayMessage("All of the super cars are displayed below;");
            DisplayMessage("");

            StringBuilder columnHeader = new StringBuilder();

            columnHeader.Append("CarID".PadRight(8));
            columnHeader.Append("Car Name".PadRight(25));

            DisplayMessage(columnHeader.ToString());

            foreach (CarInfo SuperCar in superCar)
            {
                StringBuilder SuperCarInfo = new StringBuilder();

                SuperCarInfo.Append(SuperCar.ID.ToString().PadRight(8));
                SuperCarInfo.Append(SuperCar.Name.PadRight(25));

                DisplayMessage(SuperCarInfo.ToString());
            }
        }

        // method to get the user's choice of car id
        public static int GetSuperCarID(List<CarInfo> superCar)
        {
            int SuperCarID = -1;

            DisplayAllSuperCars(superCar);

            DisplayMessage("");
            DisplayPromptMessage("Enter the car ID: ");

            SuperCarID = ConsoleUtil.ValidateIntegerResponse("Please enter the car ID: ", Console.ReadLine());

            return SuperCarID;
        }

        // method to display a car info
        public static void DisplayCarInfo(CarInfo superCar)
        {
            DisplayReset();
            Console.ForegroundColor = ConsoleColor.Red;
            DisplayMessage("");
            Console.WriteLine(ConsoleUtil.Center("Car Information", WINDOW_WIDTH));
            DisplayMessage("");
            Console.ResetColor();
            DisplayMessage(String.Format("Car: {0}", superCar.Name));
            DisplayMessage("");

            DisplayMessage(String.Format("CarID: {0}", superCar.ID.ToString()));
            DisplayMessage(String.Format("Starting Price: ${0}", superCar.Price.ToString()));
            DisplayMessage(String.Format("Car HorsePower: {0}", superCar.Horse.ToString()));
            DisplayMessage("");
        }

        // method to add a car info
        public static CarInfo AddCarInfo()
        {
            CarInfo superCar = new CarInfo();
            ConsoleView.DisplayReset();
            ConsoleView.DisplayMessage("");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(ConsoleUtil.Center("Add A Car", 79));
            Console.ResetColor();
            ConsoleView.DisplayMessage("");
            ConsoleView.DisplayPromptMessage("Enter the Car ID: ");
            superCar.ID = ConsoleUtil.ValidateIntegerResponse("Please enter the Car ID: ", Console.ReadLine());
            ConsoleView.DisplayMessage("");
            ConsoleView.DisplayPromptMessage("Enter the Car name: ");
            superCar.Name = Console.ReadLine();
            ConsoleView.DisplayMessage("");
            ConsoleView.DisplayPromptMessage("Enter the Car Price: $");
            superCar.Price = ConsoleUtil.ValidateIntegerResponse("Please the Car Price in Numbers: ", Console.ReadLine());
            ConsoleView.DisplayMessage("");
            ConsoleView.DisplayPromptMessage("Enter the Car HorsePower: ");
            superCar.Horse = ConsoleUtil.ValidateIntegerResponse("Please the Car HorsePower in Numbers: ", Console.ReadLine());
            return superCar;
        }

        public static CarInfo UpdateCarInfo(CarInfo carInfo)
        {
            string userResponse = "";
            DisplayReset();
            DisplayMessage("");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(ConsoleUtil.Center("Edit A Car", WINDOW_WIDTH));
            DisplayMessage("");
            Console.ResetColor();
            DisplayMessage(String.Format("Current Name: {0}", carInfo.Name));
            DisplayPromptMessage("Enter a new name or just press Enter to keep the current name: ");
            userResponse = Console.ReadLine();
            if (userResponse != "")
            {
                carInfo.Name = userResponse;
            }
            DisplayMessage("");
            DisplayMessage(String.Format("Current Price: ${0}", carInfo.Price.ToString()));
            DisplayPromptMessage("Enter the new price in numbers or just press Enter to keep the current price: ");
            userResponse = Console.ReadLine();
            if (userResponse != "")
            {
                carInfo.Price = ConsoleUtil.ValidateIntegerResponse("Please enter the horsepower using only numbers.", userResponse);
            }
            DisplayMessage("");
            DisplayMessage(String.Format("Current Hp: {0}", carInfo.Horse.ToString()));
            DisplayPromptMessage("Enter the new horsepower in numbers or just press Enter to keep the current horsepower: ");
            userResponse = Console.ReadLine();
            if (userResponse != "")
            {
                carInfo.Horse = ConsoleUtil.ValidateIntegerResponse("Please enter the horsepower using only numbers.", userResponse);
            }
            DisplayContinuePrompt();
            return carInfo;
        }

        // method gets the minimum and maximum values for the price query
        public static void GetPriceQueryMinMaxValues(out int minimumPrice, out int maximumPrice)
        {
            minimumPrice = 0;
            maximumPrice = 0;
            ConsoleView.DisplayReset();
            ConsoleView.DisplayMessage("");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(ConsoleUtil.Center("Query Cars by Price", 79));
            ConsoleView.DisplayMessage("");
            Console.ResetColor();
            ConsoleView.DisplayPromptMessage("Enter the minimum price: ");
            string userResponse1 = Console.ReadLine();
            if (userResponse1 != "")
                minimumPrice = ConsoleUtil.ValidateIntegerResponse("Please enter the minimum price using only numbers.", userResponse1);
            ConsoleView.DisplayMessage("");
            ConsoleView.DisplayPromptMessage("Enter the maximum price: ");
            string userResponse2 = Console.ReadLine();
            if (userResponse2 != "")
                maximumPrice = ConsoleUtil.ValidateIntegerResponse("Please enter the maximum price.", userResponse2);
            ConsoleView.DisplayMessage("");
            ConsoleView.DisplayMessage(string.Format("You have entered ${0} as the minimum price and ${1} as the maximum price.", (object)minimumPrice, (object)maximumPrice));
            ConsoleView.DisplayMessage("");
            ConsoleView.DisplayContinuePrompt();
        }

        public static void DisplayQueryResults(IEnumerable<CarInfo> matchingSuperCar)
        {
            DisplayReset();
            DisplayMessage("");
            Console.WriteLine(ConsoleUtil.Center("Display Car Price Range Results", WINDOW_WIDTH));
            DisplayMessage("");
            DisplayMessage("All of the matching cars with that price range are displayed below;");
            DisplayMessage("");
            StringBuilder columnHeader = new StringBuilder();
            columnHeader.Append("ID".PadRight(8));
            columnHeader.Append("Car Name".PadRight(25));
            DisplayMessage(columnHeader.ToString());
            foreach (CarInfo superCar in matchingSuperCar)
            {
                StringBuilder superCarInfo = new StringBuilder();

                superCarInfo.Append(superCar.ID.ToString().PadRight(8));
                superCarInfo.Append(superCar.Name.PadRight(25));

                DisplayMessage(superCarInfo.ToString());
            }      
    }

        // method gets the minimum and maximum values for the horsepower query
        public static void GetHPQueryMinMaxValues(out int minimumHorsePower, out int maximumHorsePower)
        {
            minimumHorsePower = 0;
            maximumHorsePower = 0;
            ConsoleView.DisplayReset();
            ConsoleView.DisplayMessage("");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(ConsoleUtil.Center("Query Cars by HorsePower", 79));
            ConsoleView.DisplayMessage("");
            Console.ResetColor();
            ConsoleView.DisplayPromptMessage("Enter the minimum Hp: ");
            string userResponse1 = Console.ReadLine();
            if (userResponse1 != "")
                minimumHorsePower = ConsoleUtil.ValidateIntegerResponse("Please enter the minimum HorsePower using only numbers.", userResponse1);
            ConsoleView.DisplayMessage("");
            ConsoleView.DisplayPromptMessage("Enter the maximum Hp: ");
            string userResponse2 = Console.ReadLine();
            if (userResponse2 != "")
                maximumHorsePower = ConsoleUtil.ValidateIntegerResponse("Please enter the maximum HorsePower.", userResponse2);
            ConsoleView.DisplayMessage("");
            ConsoleView.DisplayMessage(string.Format("You have entered {0} as the minimum HorsePower and {1} as the maximum HorsePower.", (object)minimumHorsePower, (object)maximumHorsePower));
            ConsoleView.DisplayMessage("");
            ConsoleView.DisplayContinuePrompt();
        }

        public static void DisplayHpResults(IEnumerable<CarInfo> matchingSuperCar)
        {
            DisplayReset();
            DisplayMessage("");
            Console.WriteLine(ConsoleUtil.Center("Display Car HorsePower Range Results", WINDOW_WIDTH));
            DisplayMessage("");
            DisplayMessage("All of the matching cars with that HorsePower are displayed below;");
            DisplayMessage("");
            StringBuilder columnHeader = new StringBuilder();
            columnHeader.Append("ID".PadRight(8));
            columnHeader.Append("Car Name".PadRight(25));
            columnHeader.Append("HorsePower".PadRight(25));
            DisplayMessage(columnHeader.ToString());
            foreach (CarInfo superCar in matchingSuperCar)
            {
                StringBuilder superCarInfo = new StringBuilder();

                superCarInfo.Append(superCar.ID.ToString().PadRight(8));
                superCarInfo.Append(superCar.Name.PadRight(25));
                superCarInfo.Append(superCar.Horse.ToString().PadRight(27));

                DisplayMessage(superCarInfo.ToString());
            }
        }

        // reset display to default size and colors including the header
        public static void DisplayReset()
        {
            Console.SetWindowSize(WINDOW_WIDTH, WINDOW_HEIGHT);

            Console.Clear();
            Console.ResetColor();

            Console.ForegroundColor = ConsoleColor.Black;
            Console.BackgroundColor = ConsoleColor.Red;

            Console.WriteLine(ConsoleUtil.FillStringWithSpaces(WINDOW_WIDTH));
            Console.WriteLine(ConsoleUtil.Center("Super Car Center", WINDOW_WIDTH));
            Console.WriteLine(ConsoleUtil.FillStringWithSpaces(WINDOW_WIDTH));

            Console.ResetColor();
            Console.WriteLine();
        }

        // display the Continue prompt
        public static void DisplayContinuePrompt()
        {
            Console.CursorVisible = false;

            Console.WriteLine();

            Console.WriteLine(ConsoleUtil.Center("Press any key to continue.", WINDOW_WIDTH));
            ConsoleKeyInfo response = Console.ReadKey();

            Console.WriteLine();

            Console.CursorVisible = true;
        }


        // display the Exit prompt
        public static void DisplayExitPrompt()
        {
            DisplayReset();

            Console.CursorVisible = false;

            Console.WriteLine();
            DisplayMessage("Thank you for using our application. Press any key to Exit.");

            Console.ReadKey();

            System.Environment.Exit(1);
        }

        // display the welcome screen
        public static void DisplayWelcomeScreen()
        {
            Console.Clear();
            Console.ResetColor();

            Console.ForegroundColor = ConsoleColor.Red;
            string tabSpace = new String(' ', 13);
            Console.WriteLine(tabSpace + @"  _ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __   ");
            Console.WriteLine(tabSpace + @" |       _____                          ______              ______           __              |  ");
            Console.WriteLine(tabSpace + @" |      / ___/__  ______  ___  _____   / ____/___ ______   / ____/__  ____  / /____  _____   |  ");
            Console.WriteLine(tabSpace + @" |      \__ \/ / / / __ \/ _ \/ ___/  / /   / __ `/ ___/  / /   / _ \/ __ \/ __/ _ \/ ___/   |  ");
            Console.WriteLine(tabSpace + @" |     ___/ / /_/ / /_/ /  __/ /     / /___/ /_/ / /     / /___/  __/ / / / /_/  __/ /       |  ");
            Console.WriteLine(tabSpace + @" |    /____/\__,_/ .___/\___/_/      \____/\__,_/_/      \____/\___/_/ /_/\__/\___/_/        |  ");
            Console.WriteLine(tabSpace + @" |              /_/                                                                          |  ");
            Console.WriteLine(tabSpace + @" |_ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __|  ");
            Console.WriteLine(tabSpace + @"");
            Console.WriteLine(tabSpace + @"                         ___...............___                                           ");
            Console.WriteLine(tabSpace + @"                  __.. ' _  '."""""" \\     """"""""-'.`-._                                      ");
            Console.WriteLine(tabSpace + @"      ______.-'         (_) |      \\           ` \\`-..                                 ");
            Console.WriteLine(tabSpace + @"     /_       --------------'-------\\---....______\\__`.` -..___                       ");
            Console.WriteLine(tabSpace + @"     | T      _.----._           Xxx|x...           |          _..`--. _                ");
            Console.WriteLine(tabSpace + @"     | |    .' ..--.. `.         XXX|XXXXXXXXXxx==  |       .'..--..`.    -._           ");
            Console.WriteLine(tabSpace + @"     \_j   /  /  __  \  \        XXX|XXXXXXXXXXX==  |      / /  __  \ \       `-.       ");
            Console.WriteLine(tabSpace + @"      _|  |  |  /  \  | |        XXX|""'             |     / |  /  \  | |         |      ");
            Console.WriteLine(tabSpace + @"     |__\_j  |  \__/  | L___________|_______________|_____j |  \__/  | L_________J      ");
            Console.WriteLine(tabSpace + @"         `'\  \      / ./__________________________________\ \       / /__________\       ");
            Console.WriteLine(tabSpace + @"             `.`----'.'                                     `.`----'.'                  ");
            Console.WriteLine(tabSpace + @"               `""""""'                                          `""""""'                     ");
            Console.WriteLine();

            DisplayContinuePrompt();
        }

        // display a message in the message area
        public static void DisplayMessage(string message)
        {
            //
            // calculate the message area location on the console window
            //
            const int MESSAGE_BOX_TEXT_LENGTH = WINDOW_WIDTH - (2 * DISPLAY_HORIZONTAL_MARGIN);
            const int MESSAGE_BOX_HORIZONTAL_MARGIN = DISPLAY_HORIZONTAL_MARGIN;

            // message is not an empty line, display text
            if (message != "")
            {
                //
                // create a list of strings to hold the wrapped text message
                //
                List<string> messageLines;

                //
                // call utility method to wrap text and loop through list of strings to display
                //
                messageLines = ConsoleUtil.Wrap(message, MESSAGE_BOX_TEXT_LENGTH, MESSAGE_BOX_HORIZONTAL_MARGIN);
                foreach (var messageLine in messageLines)
                {
                    Console.WriteLine(messageLine);
                }
            }
            // display an empty line
            else
            {
                Console.WriteLine();
            }
        }
            // display a message in the message area without a new line for the prompt
        public static void DisplayPromptMessage(string message)
        {
            //
            // calculate the message area location on the console window
            //
            const int MESSAGE_BOX_TEXT_LENGTH = WINDOW_WIDTH - (2 * DISPLAY_HORIZONTAL_MARGIN);
            const int MESSAGE_BOX_HORIZONTAL_MARGIN = DISPLAY_HORIZONTAL_MARGIN;

            //
            // create a list of strings to hold the wrapped text message
            //
            List<string> messageLines;

            //
            // call utility method to wrap text and loop through list of strings to display
            //
            messageLines = ConsoleUtil.Wrap(message, MESSAGE_BOX_TEXT_LENGTH, MESSAGE_BOX_HORIZONTAL_MARGIN);

            for (int lineNumber = 0; lineNumber < messageLines.Count() - 1; lineNumber++)
            {
                Console.WriteLine(messageLines[lineNumber]);
            }

            Console.Write(messageLines[messageLines.Count() - 1]);
        }


        #endregion
    }
}
