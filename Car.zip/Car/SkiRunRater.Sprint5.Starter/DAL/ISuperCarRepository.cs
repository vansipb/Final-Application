﻿using System;
using System.Collections.Generic;

namespace SuperCarCenter
{
    public interface ISuperCarRepository : IDisposable
    {
        CarInfo SelectById(int userID);
        List<CarInfo> SelectAll();
        void Add(CarInfo superCar);
        void Update(CarInfo superCar);
        void Delete(int ID);
    }
}
