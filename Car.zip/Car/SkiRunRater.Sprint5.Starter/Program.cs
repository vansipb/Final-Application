﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SuperCarCenter;

namespace SuperCarCenter
{
    class Program
    {
        static void Main(string[] args)
        {
            // instantiate the controller
            Controller appContoller = new Controller();
        }
    }
}
